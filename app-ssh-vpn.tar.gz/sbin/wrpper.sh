#!/bin/sh
export SSHPASS=
/home/simon/modou/app-ssh-vpn/sbin/../bin/sshpass -e /home/simon/modou/app-ssh-vpn/sbin/../bin/ssh $@
